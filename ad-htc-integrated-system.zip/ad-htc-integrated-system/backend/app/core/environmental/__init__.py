"""environmental module"""
