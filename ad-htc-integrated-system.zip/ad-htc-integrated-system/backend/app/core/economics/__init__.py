"""economics module"""
