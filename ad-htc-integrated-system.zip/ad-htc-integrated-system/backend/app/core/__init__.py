"""core module"""
