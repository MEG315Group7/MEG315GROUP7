"""thermodynamics module"""
